
# Deriv Web Bot

Este é um painel feito com Streamlit para operar na Deriv via WebSocket.

## Instruções

1. Faça fork ou clone deste repositório.
2. Acesse https://streamlit.io/cloud e crie um novo app apontando para `bot_app.py`.
3. Insira seu token da Deriv para operar.

---

Feito para fins educacionais.
